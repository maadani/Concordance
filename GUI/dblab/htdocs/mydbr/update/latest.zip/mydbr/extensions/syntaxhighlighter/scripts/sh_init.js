SyntaxHighlighter.config.clipboardSwf = "extensions/syntaxhighlighter/scripts/clipboard.swf";
SyntaxHighlighter.all();
